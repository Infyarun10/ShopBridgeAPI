prerequisites:

1. Visual Studio 2019 or .Net Core 3.1
2. Node -v14.15.1
3. Npm -v6.14.8
4. Angular CLI - v11.0.3
5. SqlServer 2019

Steps to run the application:

1. Open the ShopBridgeWebApi folder and change the connection string in launchsettings.json file
2. Build and Run the application by clicking IIS Express
3. Open the ShopBridgeDb folder and Restore the db backup file in ssms
4. Open the ShopBridgeApp in Visual studio code
4. Run the npm install and run the application using ng serve --open
5. Navigate to localhost:4200 from browser