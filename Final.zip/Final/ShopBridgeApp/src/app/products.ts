export class Products {
    productId:number;
    productName: string;
    ProductDescription: string;
    productPrice: string;
}
