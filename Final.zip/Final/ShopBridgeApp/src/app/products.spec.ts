import { Products } from './products';

describe('Products', () => {
  it('should create an instance', () => {
    expect(new Products()).toBeTruthy();
  });
});
