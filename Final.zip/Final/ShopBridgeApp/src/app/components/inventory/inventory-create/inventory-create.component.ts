import { Component, OnInit } from '@angular/core';
import { ApicallerService } from '../../../services/api-caller-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inventory-create',
  templateUrl: './inventory-create.component.html',
  styleUrls: ['./inventory-create.component.css']
})
export class InventoryCreateComponent implements OnInit {
  product = {
    name: '',
    description: '',
    price: 0
  };
  submitted = false;

  constructor(private apiCallerService: ApicallerService, private router: Router) { }

  ngOnInit(): void {
  }

  createProduct(): void {
    const data = {
      ProductName: this.product.name,
      ProductDescription: this.product.description,
      ProductPrice: this.product.price
    };

    this.apiCallerService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.router.navigate(['/inventory']);
        },
        error => {
          console.log(error);
        });
  }
  closeProduct() {
    this.router.navigate(['/inventory']);
  }

}
