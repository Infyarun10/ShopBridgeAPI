import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ApicallerService } from '../../../services/api-caller-service';

@Component({
  selector: 'app-inventory-details',
  templateUrl: './inventory-details.component.html',
  styleUrls: ['./inventory-details.component.css']
})
export class InventoryDetailsComponent implements OnInit {
  product: {
    productId: number,
    productName:string,
    productDescription: string,
    productPrice: number
  }
  
  constructor(private router: Router,private apiCallerService: ApicallerService) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation) {
      const state = navigation.extras.state as {
        productId: number,
        productName: string,
        productDescription: string,
        productPrice: number
      };
      this.product = {
        productId : state.productId,
        productName:state.productName,
        productDescription:state.productDescription,
        productPrice:state.productPrice}
    }
    
  }

  ngOnInit(): void {
   
  }
  closeProduct(){
    this.router.navigate(['/inventory']);
  }
  updateProduct(productInfo:any){

    this.apiCallerService.update(productInfo)
      .subscribe(
        response => {
          console.log("Update API response success"+response);          
          this.router.navigate(['/inventory']);
        },
        error => {
          console.log(error);
        });

  }
}
