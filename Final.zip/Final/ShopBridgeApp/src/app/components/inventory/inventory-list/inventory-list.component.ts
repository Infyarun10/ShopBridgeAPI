import { Component, OnInit } from '@angular/core';
import { ApicallerService } from '../../../services/api-caller-service';
import { Products } from '../../../products';
import {Router,NavigationExtras} from '@angular/router';

@Component({
  selector: 'app-inventory-list',
  templateUrl: './inventory-list.component.html',
  styleUrls: ['./inventory-list.component.css']
})
export class InventoryListComponent implements OnInit {

  constructor(private apiCallerService: ApicallerService,private router: Router) { }

  
  products : Products[] = [];
  currentProduct = null;
  currentIndex = -1;
  columns = ["Product Id","Product Name", "Product Description", "Product Price","Edit","Delete"];
  ngOnInit(): void {
    this.readProducts();
  }


  readProducts(): void {
    this.apiCallerService.readAll()
      .subscribe(
        products => {
          this.products = products;
          console.log(products);
        },
        error => {
          console.log(error);
        });
  }
  setCurrentProduct(product:any, index:any): void {
    this.currentProduct = product;
    this.currentIndex = index;
  }
  deleteProduct(id:any){
    if (confirm('Are you sure you want to delete this record?')) {
      this.apiCallerService.delete(id)
      .subscribe(
        response => {
          console.log('Record Deleted.' + response);
        },
        error => {
          console.log(error);
        });      
    } else {
      // Do nothing!
      console.log('Thing was not saved to the database.');
    }
    this.router.navigate(['/inventory']);
    
  }
  editProduct(product:any){
    const navigationExtras: NavigationExtras = {
      state: {
        productId: product.productId,
        productName: product.productName,
        productDescription: product.productDescription,
        productPrice: product.productPrice
      }
    };
    this.router.navigate(['/edit'], navigationExtras);
    console.log("Edit",product);
  }
  createProductNavigate(){
    this.router.navigate(['/create']);
  }
}
