﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace ShopBridge.DataAccess.DataManager
{
    public class DatabaseAccess
    {
        #region Data Members
        private ArrayList objDataParameter;

        public DatabaseAccess()
        {
            objDataParameter = new ArrayList();
        }

        public ArrayList DataBaseParameters
        {
            get
            {
                return objDataParameter;
            }
        }
        #endregion
        #region Constants

        public struct DBConstants
        {
            public const string STR_CONNECTION_STRING = "CONNECTION_STRING";
            public const string STR_RETURNVALUE_PARAM = "@RETURN_PARAM";
            public const string STR_DATABASE = "DATABASE";
        }
        #endregion

        #region Member Variables

        //Connection String

        private static string _strConnectionString = null;

        //Connection Object

        private SqlConnection objConnection;
        #endregion

        #region Public Methods
        public DataSet executeSPReturnDS(string spName)
        {
            return executeSPReturnDS(spName, null);
        }
        public DataSet executeSPReturnDS(string strSpname, ArrayList arrDataParameter)
        {
            DataSet dsSelectData = new DataSet();
            SqlDataAdapter objDataAdapter;
            SqlCommand objCommand;

            try
            {
                objDataAdapter = new SqlDataAdapter();
                objCommand = new SqlCommand();
                objCommand.CommandTimeout = 600;
                objCommand.CommandText = strSpname;
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Connection = openDataSource();                

                if (arrDataParameter != null && arrDataParameter.Count > 0)
                {                    
                    foreach (SqlParameter sp_Param in arrDataParameter)
                    {
                        objCommand.Parameters.Add(sp_Param);
                    }
                }
                objDataAdapter.SelectCommand = objCommand;
                objDataAdapter.Fill(dsSelectData);
            }
            catch (SqlException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objDataAdapter = null;
                CloseDataSource();
            }
            return dsSelectData;
        }

        public void executeSP(string strSpname, ArrayList arrDataParameter)
        {
            SqlCommand objCommand;
            try
            {
                objCommand = new SqlCommand();
                objCommand.CommandText = strSpname;
                objCommand.CommandTimeout = 600;
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Connection = openDataSource();
                if (arrDataParameter != null && arrDataParameter.Count > 0)
                {
                    foreach (SqlParameter sp_Param in arrDataParameter)
                    {
                        objCommand.Parameters.Add(sp_Param);
                    }
                }
                objCommand.ExecuteNonQuery();
            }
            catch (SqlException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                CloseDataSource();
                objCommand = null;
            }
        }
        public void AddParameter(string strParameterName,SqlDbType sqlDbType,object objParameterValue)
        {            
            SqlParameter objParameter = new SqlParameter();
            objParameter.ParameterName = strParameterName;
            objParameter.SqlDbType = sqlDbType;
            if (objParameter == null)
            {
                objParameter.Value = DBNull.Value;
            }
            else
            {
                objParameter.Value = objParameterValue;
            }
            objDataParameter.Add(objParameter);
        }

        #endregion
        #region Private Methods

        /// <summary>
        /// used for getting the Connection Object
        /// </summary>
        /// <returns></returns>
        private SqlConnection openDataSource()
        {
            //Test if SqlConection exists
            if (objConnection == null)
            {
                try
                {
                    objConnection = new SqlConnection(ReadConnectionString());
                    objConnection.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else if (objConnection.State != ConnectionState.Open)
            {
                objConnection.ConnectionString = ReadConnectionString();
                try
                {
                    objConnection.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return objConnection;
        }
        ///
        private SqlConnection CloseDataSource()
        {
            //Test if SqlConection exists
            if (objConnection == null)
            {
                try
                {
                    if (objConnection.State != ConnectionState.Open)
                    {
                        objConnection.Close();

                    }
                    objConnection = null;
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return objConnection;
        }
        private string ReadConnectionString()
        {
            try
            {
                if (_strConnectionString == null)
                {
                    _strConnectionString = ConnectionString.value;
                }
                return _strConnectionString;
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        #endregion



    }
}