﻿using System;

namespace ShopBridge.DataAccess.DataManager
{
    public class ConnectionString
    {
        public static string value { get; set; }
    }
}
