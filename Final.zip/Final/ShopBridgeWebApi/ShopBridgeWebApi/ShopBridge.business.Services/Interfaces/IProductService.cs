﻿using ShopBridge.business.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ShopBridge.business.Services
{
    public interface IProductService
    {
        public IEnumerable<ProductInformation> GetProducts();

        public int CreateProduct(ProductInformation productItem);

        public int UpdateProduct(ProductInformation productItem);

        public int DeleteProduct(Int64? productId);
    }
}
