﻿using AutoMapper;
using ShopBridge.business.Models;
using ShopBridge.DataAccess.Repository;
using ShopBridge.DataAccess.Repository.Interfaces;
using ShopBridge.DataAccess.Repository.RepositoryDao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.business.Services.ProductServices
{
    public class ProductService : IProductService
    {
        private const int V = 0;
        private readonly IProductRepository _productRepository;
        private readonly IMapper _mapper;
        public ProductService(IProductRepository productRepository, IMapper mapper)
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }
        public IEnumerable<ProductInformation> GetProducts()
        {
            IEnumerable<ProductDao> productRepository = _productRepository.GetProducts();
            IEnumerable<ProductInformation> productList = productRepository.Select(_mapper.Map<ProductInformation>).ToList();
            return productList;
        }
        public int CreateProduct(ProductInformation productItem)
        {
            //var test = _mapper.Map<ProductInformation,ProductDao>(productItem);
            var createProductDao = new ProductDao()
            {
                ProductName = productItem.ProductName,
                ProductDescription = productItem.ProductDescription,
                ProductPrice = productItem.ProductPrice
            };
            int result = _productRepository.CreateProduct(createProductDao);
            return result;
        }
        public int UpdateProduct(ProductInformation productItem)
        {
            var createProductDao = _mapper.Map<ProductInformation,ProductDao>(productItem);            
            int result = _productRepository.UpdateProduct(createProductDao);
            return result;
        }
        public int DeleteProduct(Int64? productId)
        {
            int result = _productRepository.DeleteProduct(productId);
            return result;

        }
    }
}
