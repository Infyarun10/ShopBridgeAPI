﻿using System;

namespace ShopBridge.Business.Common
{
    public class BusinessCommon
    {
        #region Store procedure details
        public const string STR_GET_ALL_PRODUCTS = "SP_Get_ProductList";
        public const string STR_CREATE_PRODUCT = "SP_Create_Product";
        public const string STR_UPDATE_PRODUCT = "SP_Update_Product";
        public const string STR_DELETE_PRODUCT = "SP_Delete_Product";
        #endregion
    }
}
