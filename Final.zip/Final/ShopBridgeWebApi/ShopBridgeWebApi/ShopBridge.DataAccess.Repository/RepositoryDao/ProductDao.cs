﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShopBridge.DataAccess.Repository.RepositoryDao
{
    public class ProductDao
    {
        public Int64 ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public decimal ProductPrice { get; set; }
    }
}
