﻿using ShopBridge.Business.Common;
using ShopBridge.DataAccess.DataManager;
using ShopBridge.DataAccess.Repository.Interfaces;
using ShopBridge.DataAccess.Repository.RepositoryDao;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ShopBridge.DataAccess.Repository
{
    public class ProductRepository : IProductRepository
    {
        //private readonly IProductRepository _productRepository;
        private readonly DatabaseAccess _databaseAccess;
        public ProductRepository(DatabaseAccess databaseAccess)
        {
            //_productRepository = productRepository;
            _databaseAccess = databaseAccess;
        }
        public IEnumerable<ProductDao> GetProducts()
        {
            try
            {
                DataSet productCollection = _databaseAccess.executeSPReturnDS(BusinessCommon.STR_GET_ALL_PRODUCTS);

                IEnumerable<ProductDao> productList = productCollection.Tables[0].AsEnumerable().Select(DataRow => new ProductDao
                {
                    ProductId = DataRow.Field<Int64>("ProductId"),
                    ProductName = DataRow.Field<string>("ProductName"),
                    ProductDescription = DataRow.Field<string>("ProductDescription"),
                    ProductPrice = DataRow.Field<decimal>("ProductPrice")

                });
                return productList;
            }
            catch(Exception Ex)
            {
                throw Ex;
            }
        }
        public int CreateProduct(ProductDao productItem)
        {
            try
            {
                _databaseAccess.AddParameter("@ProductName", SqlDbType.VarChar, productItem.ProductName);
                _databaseAccess.AddParameter("@ProductDescription", SqlDbType.VarChar, productItem.ProductDescription);
                _databaseAccess.AddParameter("@ProductPrice", SqlDbType.VarChar, productItem.ProductPrice);
                _databaseAccess.executeSP(BusinessCommon.STR_CREATE_PRODUCT, _databaseAccess.DataBaseParameters);
                return 0;
            }
            catch (Exception Ex)
            {
                return 1;
            }
        }
        public int UpdateProduct(ProductDao productItem)
        {
            try
            {
                _databaseAccess.AddParameter("@ProductId", SqlDbType.BigInt, productItem.ProductId);
                _databaseAccess.AddParameter("@ProductName", SqlDbType.VarChar, productItem.ProductName);
                _databaseAccess.AddParameter("@ProductDescription", SqlDbType.VarChar, productItem.ProductDescription);
                _databaseAccess.AddParameter("@ProductPrice", SqlDbType.VarChar, productItem.ProductPrice);
                _databaseAccess.executeSP(BusinessCommon.STR_UPDATE_PRODUCT, _databaseAccess.DataBaseParameters);
                return 0;
            }
            catch (Exception Ex)
            {
                return 1;
            }
        }
        public int DeleteProduct(Int64? productId)
        {
            try
            {
                _databaseAccess.AddParameter("@ProductId", SqlDbType.BigInt, productId);
                _databaseAccess.executeSP(BusinessCommon.STR_DELETE_PRODUCT, _databaseAccess.DataBaseParameters);
                return 0;
            }
            catch (Exception Ex)
            {
                return 1;
            }
        }
    }
}
