﻿using ShopBridge.DataAccess.Repository.RepositoryDao;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ShopBridge.DataAccess.Repository.Interfaces
{
    public interface IProductRepository
    {
        public IEnumerable<ProductDao> GetProducts();
        public int CreateProduct(ProductDao productItem);
        public int UpdateProduct(ProductDao productItem);

        public int DeleteProduct(Int64? productId);
    }
}
