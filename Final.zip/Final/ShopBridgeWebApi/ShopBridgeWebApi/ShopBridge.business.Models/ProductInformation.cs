﻿using System;

namespace ShopBridge.business.Models
{
    public class ProductInformation
    {
        public Int64 ProductId { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public decimal ProductPrice { get; set; }
    }
}
