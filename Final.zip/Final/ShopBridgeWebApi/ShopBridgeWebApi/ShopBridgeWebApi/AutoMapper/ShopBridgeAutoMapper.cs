﻿using AutoMapper;
using ShopBridge.business.Models;
using ShopBridge.DataAccess.Repository.RepositoryDao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridgeWebApi.AutoMapper
{
    public class ShopBridgeAutoMapper : Profile
    {
        public ShopBridgeAutoMapper()
        {
            CreateMap<ProductDao, ProductInformation>();
            CreateMap<ProductInformation, ProductDao>();
        }
    }
}
