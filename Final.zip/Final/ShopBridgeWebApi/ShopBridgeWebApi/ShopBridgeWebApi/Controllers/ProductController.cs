﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShopBridge.business.Models;
using ShopBridge.business.Services;

namespace ShopBridgeWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }
        [HttpGet]
        public bool Get()
        {
            return true;
        }
        [HttpGet]
        [Route("GetProducts")]
        public ActionResult<IEnumerable<ProductInformation>> GetProducts()
        {
            try
            {
                var productList = _productService.GetProducts();
                if(productList == null)
                {
                    return NotFound();
                }
                return Ok(productList);
            }
            catch(Exception Ex)
            {
                throw Ex;                
            }
        }
        [HttpPost]
        [Route("CreateProduct")]
        public IActionResult CreateProduct([FromBody]ProductInformation productInformation)
        {
            try
            {
                var productId = _productService.CreateProduct(productInformation);
                if (productId == 0)
                {
                    return Ok(productId);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception Ex)
            {
                throw Ex;
            }

        }
        [HttpPut]
        [Route("UpdateProduct")]
        public IActionResult UpdateProduct([FromBody] ProductInformation productInformation)
        {
            try
            {
                var productId = _productService.UpdateProduct(productInformation);
                if (productId == 0)
                {
                    return Ok(productId);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception Ex)
            {
                throw Ex;
            }

        }
        [HttpDelete]
        [Route("DeleteProduct/{productId}")]
        public IActionResult DeleteProduct(Int64? productId)
        {
            try
            {
                var result = _productService.DeleteProduct(productId);
                if (result == 0)
                {
                    return Ok(result);
                }
                else
                {
                    return NotFound();
                }

            }
            catch (Exception Ex)
            {
                throw Ex;
            }

        }
    }
}
